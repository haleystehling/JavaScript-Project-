var background = document.getElementById('background-color');
background.addEventListener('click', changeColor, false);
 
var colors = ["grey", "aqua", "cornflowerblue", "salmon", "orange", "black", "purple", "pink"];

function changeColor() {
    var col = document.getElementById('background-color');
    col.style.backgroundColor = colors[Math.floor((Math.random()*4)+1)];
}



var text = document.getElementById('my-text');
text.addEventListener('mouseover', textColor, false);

function textColor() {
    var text = document.getElementById('my-text').style.color="black";
}


var text = document.getElementById('my-text');
text.addEventListener('mouseout', originalColor, false);

function originalColor() {
    var text = document.getElementById('my-text').style.color="white";
}






